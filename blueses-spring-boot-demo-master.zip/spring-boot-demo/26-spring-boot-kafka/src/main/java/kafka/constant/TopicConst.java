package kafka.constant;

public final class TopicConst {

    public static final String EXECUTOR_TOPIC = "executorTopic";

}



