package spring.boot.i18n;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringBootI18nApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootI18nApplication.class, args);
	}
}


