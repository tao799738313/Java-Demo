package spring.boot.knife4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKnife4jApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKnife4jApplication.class, args);
	}
}


