package sqlite;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("sqlite.mapper")
public class SQLiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SQLiteApplication.class, args);
	}
}
