package up;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpLoadApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpLoadApplication.class, args);
	}
}
