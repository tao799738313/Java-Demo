package org.javaboy.sessionshare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionshareApplication {

    public static void main(String[] args) {
        SpringApplication.run(SessionshareApplication.class, args);
    }

}
