package org.javaboy.jparest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(JpaRestApplication.class, args);
    }

}
