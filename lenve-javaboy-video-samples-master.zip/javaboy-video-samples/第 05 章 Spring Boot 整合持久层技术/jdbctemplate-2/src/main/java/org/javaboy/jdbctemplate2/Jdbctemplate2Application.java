package org.javaboy.jdbctemplate2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jdbctemplate2Application {

    public static void main(String[] args) {
        SpringApplication.run(Jdbctemplate2Application.class, args);
    }

}
