package org.javaboy.mybatis2.mapper1;

import org.javaboy.mybatis2.bean.User;

import java.util.List;

/**
 * @Author 江南一点雨
 * @Site www.javaboy.org 2019-07-28 11:19
 */
public interface UserMapper1 {
    List<User> getAllUsers();
}
