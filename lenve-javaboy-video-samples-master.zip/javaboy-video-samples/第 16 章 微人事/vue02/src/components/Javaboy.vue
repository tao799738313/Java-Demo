<template>
    <div>
      <h1>hello javaboy!</h1>
    </div>
</template>

<script>
    export default {
        name: "Javaboy"
    }
</script>

<style scoped>

</style>
