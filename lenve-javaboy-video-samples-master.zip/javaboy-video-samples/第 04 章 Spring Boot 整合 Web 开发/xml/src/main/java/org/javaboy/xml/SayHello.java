package org.javaboy.xml;

/**
 * @Author 江南一点雨
 * @Site www.javaboy.org 2019-07-24 17:11
 */
public class SayHello {
    public String sayHello() {
        return "hello xml";
    }
}
