package org.javaboy.securitydy.mapper;

import org.javaboy.securitydy.bean.Menu;

import java.util.List;

/**
 * @Author 江南一点雨
 * @Date 2019-08-11 17:27
 */
public interface MenuMapper {
    List<Menu> getAllMenus();
}
