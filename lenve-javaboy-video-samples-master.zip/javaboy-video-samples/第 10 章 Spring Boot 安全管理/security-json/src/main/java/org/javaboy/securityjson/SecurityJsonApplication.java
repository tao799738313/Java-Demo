package org.javaboy.securityjson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityJsonApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecurityJsonApplication.class, args);
    }

}
