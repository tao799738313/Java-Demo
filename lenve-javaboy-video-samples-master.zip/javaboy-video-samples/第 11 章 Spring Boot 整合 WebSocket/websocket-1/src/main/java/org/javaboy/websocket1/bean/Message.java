package org.javaboy.websocket1.bean;

/**
 * @Author 江南一点雨
 * @Site www.javaboy.org 2019-08-14 12:14
 */
public class Message {
    private String name;
    private String content;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
