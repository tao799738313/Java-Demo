package iterator01;

public interface Container {
    public Iterator getIterator();
}
