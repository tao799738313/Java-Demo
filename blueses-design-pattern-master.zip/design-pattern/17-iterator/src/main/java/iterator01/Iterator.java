package iterator01;

public interface Iterator {
    public boolean hasNext();
    public Object next();
}