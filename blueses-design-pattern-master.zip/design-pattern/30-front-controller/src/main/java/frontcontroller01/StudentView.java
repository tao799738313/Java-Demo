package frontcontroller01;

public class StudentView {
    public void show(){
        System.out.println("Displaying Student Page");
    }
}
