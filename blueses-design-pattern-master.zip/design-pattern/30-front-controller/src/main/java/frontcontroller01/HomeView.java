package frontcontroller01;

public class HomeView {
    public void show(){
        System.out.println("Displaying Home Page");
    }
}
