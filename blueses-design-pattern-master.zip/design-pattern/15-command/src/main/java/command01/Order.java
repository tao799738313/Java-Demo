package command01;

public interface Order {
    void execute();
}
