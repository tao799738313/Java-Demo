package builder01.meal;

import builder01.item.burger.ChickenBurger;
import builder01.item.colddrink.Coke;
import builder01.item.colddrink.Pepsi;
import builder01.item.burger.VegBurger;

public class MealBuilder {

    public Meal prepareVegMeal (){
        Meal meal = new Meal();
        meal.addItem(new VegBurger());
        meal.addItem(new Coke());
        return meal;
    }

    public Meal prepareNonVegMeal (){
        Meal meal = new Meal();
        meal.addItem(new ChickenBurger());
        meal.addItem(new Pepsi());
        return meal;
    }
}
