package builder01.packing;

public interface Packing {
    public String pack();
}