package interpreter01;

public interface Expression {
    public boolean interpret(String context);
}
