package servicelocator01.service;

public interface Service {
    public String getName();
    public void execute();
}
