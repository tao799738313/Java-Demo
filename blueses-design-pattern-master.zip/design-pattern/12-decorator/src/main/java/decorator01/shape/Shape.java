package decorator01.shape;

public interface Shape {
    void draw();
}
