package state01;

public interface State {
    void doAction(Context context);
}
