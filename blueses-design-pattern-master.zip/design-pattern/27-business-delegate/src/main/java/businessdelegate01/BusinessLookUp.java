package businessdelegate01;

import businessdelegate01.service.BusinessService;
import businessdelegate01.service.EJBService;
import businessdelegate01.service.JMSService;

public class BusinessLookUp {
    public BusinessService getBusinessService(String serviceType){
        if(serviceType.equalsIgnoreCase("EJB")){
            return new EJBService();
        }else {
            return new JMSService();
        }
    }
}
