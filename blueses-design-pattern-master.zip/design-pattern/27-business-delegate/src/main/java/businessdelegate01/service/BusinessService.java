package businessdelegate01.service;

public interface BusinessService {
    public void doProcessing();
}
