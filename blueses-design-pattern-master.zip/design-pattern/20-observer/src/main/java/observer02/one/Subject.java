package observer02.one;

import java.util.Observable;

/**
 * 利用jdk实现一对多的一
 */
public class Subject extends Observable {

    private int state;

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
        this.setChanged();
        this.notifyObservers();
    }
}
