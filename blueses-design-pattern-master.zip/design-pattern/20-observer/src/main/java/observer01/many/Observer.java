package observer01.many;

import observer01.one.Subject;

/**
 * 一对多的多
 */
public abstract class Observer {
    protected Subject subject;
    public abstract void update();
}
