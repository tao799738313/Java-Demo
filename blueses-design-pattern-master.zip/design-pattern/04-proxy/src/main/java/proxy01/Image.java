package proxy01;

public interface Image {
    void display();
}
