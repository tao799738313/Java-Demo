package proxy02;

public interface Subject {
    public int sellBooks();

    public String speak();
}
