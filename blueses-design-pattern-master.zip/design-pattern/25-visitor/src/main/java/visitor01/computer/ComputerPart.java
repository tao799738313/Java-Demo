package visitor01.computer;

import visitor01.ComputerPartVisitor;

/**
 * 定义一个表示元素的接口。
 */
public interface ComputerPart {
    public void accept(ComputerPartVisitor computerPartVisitor);
}
