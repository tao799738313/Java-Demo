package flyweight01;

public interface Shape {
    void draw();
}
