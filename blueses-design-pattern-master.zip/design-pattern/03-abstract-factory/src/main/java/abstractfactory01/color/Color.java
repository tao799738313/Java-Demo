package abstractfactory01.color;

/**
 * 为颜色创建一个接口
 */
public interface Color {
    void fill();
}
