package singleton01;

/**
 * Main，我们的演示类使用 SingleObject 类来获取 SingleObject 对象。
 */
public class Main {
    public static void main(String[] args) {
        SingleObject singleObject = SingleObject.getInstance();
        singleObject.showMessage();
    }
}
