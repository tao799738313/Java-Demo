package interceptingfilter01.filter;

public interface Filter {
    public void execute(String request);
}
