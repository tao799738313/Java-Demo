package interceptingfilter01;

import interceptingfilter01.filter.Filter;
import interceptingfilter01.filter.FilterChain;
import interceptingfilter01.filter.Target;

public class FilterManager {
    FilterChain filterChain;

    public FilterManager(Target target){
        filterChain = new FilterChain();
        filterChain.setTarget(target);
    }
    public void setFilter(Filter filter){
        filterChain.addFilter(filter);
    }

    public void filterRequest(String request){
        filterChain.execute(request);
    }
}
